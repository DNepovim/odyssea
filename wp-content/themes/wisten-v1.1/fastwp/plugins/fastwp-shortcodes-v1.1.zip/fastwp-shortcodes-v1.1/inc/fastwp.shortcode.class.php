<?php
/**
 * @package FastWP_Shortcodes
 * @version 1.0
 */
if(!class_exists('fastwp_shortcodes')):
	class fastwp_shortcodes {

	}
endif;


class fastwp_shortcodes_fe extends fastwp_shortcodes {
	static function call_to_action( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'color'		=> '#eeeeee',
			'pointer'	=> 'bottom',
		), $atts));
		$before = $after = '';
		if($pointer == 'top'){
			$before = '<a class="fastwp-arrow-top" style="border-bottom-color:'.$color.'"></a>';
		}else {
			$after 	= '<a class="fastwp-arrow-bottom" style="border-top-color:'.$color.'"></a>';
		}
		return sprintf('<div class="fastwp-call-to-action">%s<div class="cta-content" style="background-color:%s">%s</div>%s</div>', $before, $color, do_shortcode($content), $after);
	}
	
	static function fastwp_get_page( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'id'	=> '0',
			'slug' => ''
		), $atts));
		if($id != '0' && $id != ''){
			$page = get_page($id, OBJECT, 'display');
		} else if($slug != ''){
			$page = get_page_by_path($slug);
		}
		if(!isset( $page->post_content)) return;
		return sprintf('<div class="fastwp-page">%s</div>', apply_filters('the_content', $page->post_content));
	}
	
	static function get_tweets($account, $use_cache = 'true'){
		global $smof_data;
		$current_dir = dirname(dirname(__FILE__));
		$cache_file = $current_dir.'/cache/twitter.json';
		if(!file_exists($cache_file) || (filemtime($cache_file) + 60) < time()){
			/* Default to FastWP API keys. Use yours inside admin. No edit needed */			
			$token 				= (isset($smof_data['twt_api_token']) 			&& !empty($smof_data['twt_api_token']))? 			$smof_data['twt_api_token'] 			: "40743312-y3liCcAOihr7rUUtfQ3roaiYEVcCsM8tv7bpV21PO";
			$token_secret 		= (isset($smof_data['twt_api_token_secret']) 	&& !empty($smof_data['twt_api_token_secret']))? 	$smof_data['twt_api_token_secret'] 		: "6OL8O5LQJFIoHjcOml29L1TKyDhEkGGMTf78PxCE";
			$consumer_key 		= (isset($smof_data['twt_api_consumer_key']) 	&& !empty($smof_data['twt_api_consumer_key']))?		$smof_data['twt_api_consumer_key'] 		: "qMwvjfLy4NUbRIYo7flwUQ";
			$consumer_secret 	= (isset($smof_data['twt_api_consumer_secret']) && !empty($smof_data['twt_api_consumer_secret']))? 	$smof_data['twt_api_consumer_secret'] 	: "DdqVDcmF9LbCqhYfLPPgvcWh54XVQpZnu5KqjcMg";
			
			/* Twitter API stuff */
			$host = 'api.twitter.com';
			$method = 'GET';
			$path = '/1.1/statuses/user_timeline.json'; 
			$query = array( 'screen_name' => $account );
			
			/* oAuth system */
			$oauth = array(
				'oauth_consumer_key' => $consumer_key,
				'oauth_token' => $token,
				'oauth_nonce' => (string)mt_rand(), // a stronger nonce is recommended
				'oauth_timestamp' => time(),
				'oauth_signature_method' => 'HMAC-SHA1',
				'oauth_version' => '1.0'
			);
			$oauth = array_map("rawurlencode", $oauth); // must be encoded before sorting
			$query = array_map("rawurlencode", $query);
			$arr = array_merge($oauth, $query); // combine the values THEN sort
			asort($arr); // secondary sort (value)
			ksort($arr); // primary sort (key)
			$querystring = urldecode(http_build_query($arr, '', '&'));
			$url = "https://$host$path";
			$base_string = $method."&".rawurlencode($url)."&".rawurlencode($querystring);
			$key = rawurlencode($consumer_secret)."&".rawurlencode($token_secret);
			$signature = rawurlencode(base64_encode(hash_hmac('sha1', $base_string, $key, true)));
			$url .= "?".http_build_query($query);
			$oauth['oauth_signature'] = $signature; 
			ksort($oauth); 
			function add_quotes($str) { return '"'.$str.'"'; }
			$oauth = array_map("add_quotes", $oauth);
			$auth = "OAuth " . urldecode(http_build_query($oauth, '', ', '));

			/* Get feed */
			$options = array( 
				CURLOPT_HTTPHEADER => array("Authorization: $auth"),
				CURLOPT_HEADER => false,
				CURLOPT_URL => $url,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_SSL_VERIFYPEER => false
			);
			$feed = curl_init();
			curl_setopt_array($feed, $options);
			$output = curl_exec($feed); 
			curl_close($feed);
			$cache_pointer = @fopen($cache_file,'w');
			@fwrite($cache_pointer, $output);
			@fclose($cache_pointer);
		}else {
			$output = file_get_contents($cache_file);
		}
		return @json_decode($output);
	}
	
	static function twitter_feed($atts, $content){
		extract(shortcode_atts(array(
		  'account' 	=> '',
		  'limit' 		=> '5',
		  'show_reply' 	=> '1',
		  'use_cache' 	=> 'true',
		), $atts));
		if($account == '') return;
		$date_format = get_option('date_format');
		$content = self::get_tweets($account, $use_cache);
		
		$out = '';
		if(isset($content->error) || isset($content->errors)) return;

		$found = 0;
		$wrapper_template = '<div class="fastwp-twitter twitter"><div class="container clearfix group"><div class="twitter-image"><a href="https://twitter.com/%s" target="_blank"><i class="fa fa-twitter"></i></a></div><div class="twitter-feed relative"><ul class="text-slider clearfix group">%s</ul></div></div></div>';
		$tweet_template = '<li id="twt-%s"><h2>"%s"</h2><p class="twitter-white"><a href="https://twitter.com/%s" target="_blank">@%s</a> - %s</p></li>';
		if(count($content) > 0){
			foreach($content as $tweet){
				if($found < $limit){
					$srid = (int) $tweet->in_reply_to_user_id;
					if($srid == 0 || $show_reply == '1'){
						$date = date($date_format, strtotime($tweet->created_at));
						$author = $tweet->user->screen_name;
						$text = $tweet->text;
						$tweet_id = (int) $tweet->in_reply_to_status_id;
						$out .= sprintf($tweet_template, $tweet_id, $text, $author, $author, $date);
						$found++;
					}
				}
			}
		}
		return sprintf($wrapper_template, $account, $out);
	}

	static function full_background($atts, $content){
		extract(shortcode_atts(array(
			'image'		=> '',
			'direction'	=> 'h',
			'speed'		=> '70',
			'size'		=> 'cover',
			'scroll'	=> 'false',
			'pattern'	=> 'false',
		), $atts));	
		$class = ($scroll != 'false')? ' with-scroll-bg' : '';
		$class .= ($pattern == 'true')? ' relative':'';
		$content_index = ($pattern == 'true')? ' relative index-2 ' : '';
		$pattern_html = ($pattern == 'true')? '<div class="pattern index-1"></div>' : '';
		$item_html = '<div class="fastwp-full-bg %s" data-speed="%s" data-direction="%s" style="background-image:url(%s); background-size:%s">%s<div class="fastwp-bg-content %s">%s</div></div>';
		return sprintf($item_html, $class, $speed, $direction, $image, $size, $pattern_html, $content_index, do_shortcode($content));
	}
	
	static function parallax($atts, $content){
		extract(shortcode_atts(array(
			'image'		=> '',
			'color'		=> '',
			'speed'		=> '50',
		), $atts));	
		
		return '<div class="fastwp-parallax" data-speed="'.$speed.'" style="background-image:url('.$image.'); '.(($color != '')?'color:'.$color.';':'').'">'.do_shortcode($content).'</div>';
	}
	
	static function testimonials($atts, $content){
		extract(shortcode_atts(array(
			'include'		=> '',
			'exclude'		=> '',
			'limit'			=> '-1',
		), $atts));		

		$query 			= array( 'post_type' => 'fwp_testimonial', 'numberposts' => $limit, 'orderby'=>'menu_order', 'order'=>'ASC' );
		if($include != ''){ $query['include'] = $include; }
		if($exclude != ''){ $query['exclude'] = $exclude; }

		$output_html 	= '';
		$items 			= get_posts($query);
		
		for($i=0; $i < count($items); $i++){
			$output_html .= '
			<div class="monial">
					<h1 class="big"> '.do_shortcode($items[$i]->post_content).'</h1>
					<p class="name">- '.$items[$i]->post_title.' -</p>
				</div>
			';
		}

		return '<div class="testimonial"><div class="testimonials clearfix group">'.$output_html.'</div></div>';
	}

	static function newsletter_form($atts, $content){
		extract(shortcode_atts(array(
			'icon'	=> 'envelope-o',
			'email_label'	=> __('Your email address','fastwp'),
			'submit_label'	=> __('Subscribe','fastwp'),
			'action'=>home_url(),
		), $atts));	
		return '<section class="contain subscribe-wrap">
			<div class="inner subscribe">
					<div class="col-xs-7 subs left">
						<a class="left-icon">
							<i class="fa fa-'.$icon.'"></i>
						</a>
						<div class="text">'.trim($content).'</div><div class="clear"></div>
					</div>
					<div class="col-xs-5 subs right">
						<form id="subscribe-mail" method="post" action="'.$action.'">
						<input type="email" class="subscribe-mail" required="required" name="EMAIL" id="e-mail" placeholder="'.$email_label.'">
						<button type="submit" class="subscribe-btn subs">'.$submit_label.'</button>
						<input type="hidden" name="_mc4wp_form_submit" value="1" />
						<input type="hidden" name="_mc4wp_form_instance" value="1" />
						<input type="hidden" name="_mc4wp_form_nonce" value="'. wp_create_nonce( '_mc4wp_form_nonce' ) .'" />
						 </form></div><div class="clear"></div></div></section>';
	}

	static function members($atts, $content){
		global $fastwp_social_networks;
		extract(shortcode_atts(array(
			'nav_pos'	=> 'top',
			'include'	=> '',
			'exclude'	=> '',
			'ribbon'	=> 'img-circle',
			'limit'		=> '-1',
			'config'	=> '',
		), $atts));		
		$oitems = array();
		$delay 	= 0;
		$items_wrapper = '<div class="team-items slide-boxes" %s>%s</div>';
		$item_template = '<div class="item animated" data-animation="flipInY" data-animation-delay="%s" %s><img src="%s" alt="" class="%s" /><h3>%s</h3><h4>%s</h4><div class="member-excerpt">%s</div><div class="socials">%s</div></div>';
		$social_template = '<a href="%s"><i class="fa fa-%s"></i></a>';						
		$query 			= array( 'post_type' => 'fwp_team', 'numberposts' => $limit, 'orderby'=>'menu_order', 'order'=>'ASC' );
		if($include != ''){ $query['include'] = $include; }
		if($exclude != ''){ $query['exclude'] = $exclude; }

		$services_html 	= '';
		$items 			= get_posts($query);	
		$_config 		= ($config != '')? sprintf(' data-config="%s"', $config):'';
		foreach($items as $item){
			$target_url = '';
			$value = get_post_meta( $item->ID, '_fastwp_meta', true );
			$name = $item->post_title;
			$title = (isset($value['title']) && !empty($value['title']))?$value['title']:'';
			$bio = apply_filters('the_excerpt',@$value['excerpt']);
			$photo = wp_get_attachment_image_src( get_post_thumbnail_id( $item->ID ), 'member-photo' );
			$social = '';
			foreach($fastwp_social_networks as $sname=>$icon){
				$current_value = (isset($value['social'][$sname]))?esc_attr( $value['social'][$sname] ):'';
				if($current_value == '' || $current_value == '#') continue;
				$social .= sprintf($social_template, $current_value, str_replace('_','-', $icon));
			}
			if(isset($value['url']) && !empty($value['url']) && $value['url'] != '#'){
				$target_url = ' data-url="'.$value['url'].'" onClick="document.location=\''.$value['url'].'\'"';
			}
			$oitems[] = sprintf($item_template, $delay, $target_url, $photo[0], $ribbon, $name, $title, $bio, $social);
			$delay += 300;
		}
	
		return sprintf($items_wrapper, $_config, implode("\n", $oitems));
	}

	static function pie_chart($atts, $content){
		extract(shortcode_atts(array(
			'label' 	=> '',
			'percent'	=> '0',
		), $atts));		
		
		return '<div class="pie-chart-wrapper"><span class="pie-chart" data-percent="'.$percent.'">
		<span class="percent"></span>
	</span><div class="chart-label">'.$label.'</div></div>';
	}
	
	static function services($atts, $content){
		extract(shortcode_atts(array(
			'text_position' => 'top',
			'include'		=> '',
			'exclude'		=> '',
			'use_parallax'	=> 'true',
			'background'	=> false,
			'limit'			=> '-1',
			'icon'			=> 'cogs',
			'target'		=> '_self',
			'config'		=> '',
		), $atts));		

		$query 			= array( 'post_type' => 'fwp_service', 'numberposts' => $limit, 'orderby'=>'menu_order', 'order'=>'ASC' );
		if($include != ''){ $query['include'] = $include; }
		if($exclude != ''){ $query['exclude'] = $exclude; }

		$services_html 	= '';
		$items 			= get_posts($query);
		$text 			= do_shortcode($content);
		
		for($i=0; $i < count($items); $i++){
			$_meta 	= get_post_meta($items[$i]->ID, '_fastwp_meta', true);
			$_icon 	= (isset($_meta['service_icon']))? $_meta['service_icon'] : 'fa-cogs';
			$_url	= (isset($_meta['url']))? $_meta['url'] : 'javascript:void(0)';
			$delay 	= 200 * $i;
			$services_html .= '
			<li class="service box animated" data-animation="flipInY" data-animation-delay="'.$delay.'">
				<a href="'.$_url.'" target="'.$target.'" class="service-logo">
					<i class="fa '.$_icon.'"></i>
				</a>
				<h3>'.$items[$i]->post_title.'</h3>
				<p>'.$items[$i]->post_content.'</p>
			</li>
			';
		}
		$_style 		= ($background != false && $background != 'false')? 'background-image:url('.$background.');' : '';
		$_use_parallax 	= ($use_parallax == 'true')? 'parallax' : '';
		$_rand			= rand(1000,9999);
		$_config 		= ($config != '')? sprintf(' data-config="%s"', $config):'';
		return '
		<div class="services bg '.$_use_parallax.'" style="'.$_style.'" id="services-'.$_rand.'">
			<div class="inner services">
				'.(($text_position == 'top')?$text:'').'
				<ul class="service-contents slide-boxes" '.$_config.'>
				'.$services_html.'
				</ul>
				'.(($text_position == 'bottom')?$text:'').'
			</div>
		</div>';
	}
	
	static function productInfo($atts, $content){
		extract(shortcode_atts(array(
			'b1label' 	=> __('Purchase','fastwp'),
			'b1url' 	=> '',
			'b2label' 	=> __('Read More','fastwp'),
			'b2url' 	=> '',
			'background'=> '',
		), $atts));	
		$style = ($background != '')? ' style="background:'.$background.'"':'';
		return '<!-- Text Area -->
		<section id="text-area" '.$style.'>
			<div class="inner text-area">
			<h1>'.do_shortcode($content).'</h1>
				'.(($b1url != '')?'<a href="'.$b1url.'" class="button">'.$b1label.'</a>':'').'
				'.(($b2url != '')?'<a href="'.$b2url.'" class="button">'.$b2label.'</a>':'').'
			</div>
		</section><!-- End Text Area -->';
	}
	
	static function box($atts, $content){
		extract(shortcode_atts(array(
			'nopadding' => false,
		), $atts));	
		return '<div class="inner '.(($nopadding != false)?'no-padding':'').'">'.do_shortcode($content).'</div>';
	}
		
	static function with_border($atts, $content){
		return '<div class="fastwp-box-border">'.do_shortcode($content).'</div>';
	}
	
	static function header($atts, $content){
		extract(shortcode_atts(array(
			'position' 	=> '',
			'class'		=>'header',
			'color'		=> '',
			'animation'	=> '',
			'delay'		=> '0',
		), $atts));		
		$data_property = '';
		if($animation != ''){
			$class .= ' animated';
			$data_property = 'data-animation="'.$animation.'" data-delay="'.$delay.'"';
		}
		return '<div class="'.$class.' '.(($position != '')?'falign-'.$position:'').'" style="'.(($color != '')?'color:'.$color:'').'" '.$data_property.'>'.do_shortcode($content).'</div>';
	}
	
	static function desc($atts, $content){
		extract(shortcode_atts(array(
			'position' 	=> '',
			'color'		=> '',
			'class'		=> '',
			'animation'	=> '',
			'delay'		=> '0',
		), $atts));	
		$data_property = '';
		if($animation != ''){
			$class .= ' animated';
			$data_property = 'data-animation="'.$animation.'" data-delay="'.$delay.'"';
		}
		return '<div class="page-desc '.$class.' '.(($position != '')?'falign-'.$position:'').'" style="'.(($color != '')?'color:'.$color:'').'" '.$data_property.'>'.do_shortcode($content).'</div>';
	}
		
	static function fastwp_phone($atts, $content){
		extract(shortcode_atts(array(
			'icon1' => 'camera-retro',
			'icon2' => 'pagelines',
			'icon3' => 'laptop',
			'icon4' => 'cloud-upload',
			'ct1' => 'Lorem Ipsum',
			'ct2' => 'Lorem Ipsum',
			'ct3' => 'Lorem Ipsum',
			'ct4' => 'Lorem Ipsum',
			'title1' => 'photography',
			'title2' => 'design',
			'title3' => 'analystic',
			'title4' => 'online support',
			'animated'=>'true',
			'image'	=> get_template_directory_uri().'/images/f-iphone.png',
		), $atts));	
		$class = ($animated=='true')?'animated':'';
		return sprintf('<div class="fastp-phone-shortcode"><ul class="f-iphone clearfix group" style="background-image:url(%s);">
				<li class="f-box f1 %s" data-animation="fadeInLeft" data-animation-delay="0"><div class="f-box-logo"><i class="fa fa-%s"></i></div><div class="f-box-head">%s</div><div class="f-box-desc">%s</div></li>
				<li class="f-box f2 %s" data-animation="fadeInRight" data-animation-delay="200"><div class="f-box-logo"><i class="fa fa-%s"></i></div><div class="f-box-head">%s</div><div class="f-box-desc">%s</div></li>
				<li class="f-box f3 %s" data-animation="fadeInLeft" data-animation-delay="400"><div class="f-box-logo"><i class="fa fa-%s"></i></div><div class="f-box-head">%s</div><div class="f-box-desc">%s</div></li>
				<li class="f-box f4 %s" data-animation="fadeInRight" data-animation-delay="600"><div class="f-box-logo"><i class="fa fa-%s"></i></div><div class="f-box-head">%s</div><div class="f-box-desc">%s</div></li>
			</ul></div>', $image, $class, $icon1, $title1, $ct1, $class, $icon2, $title2, $ct2, $class, $icon3, $title3, $ct3, $class, $icon4, $title4, $ct4);
	}
	
	static function divider($atts, $content){
		extract(shortcode_atts(array(
		  'type'		=> '', 
		), $atts));
		return '<div class="divider'.(($type != '')?" $type ":'').'"></div>';
	}
	
	static function space($atts, $content){
		extract(shortcode_atts(array(
		  'height'		=> 5,
		), $atts));
		return '<div class="space" style="clear:both; height:'.$height.'px;"></div>';
	}
	
	static function pricing_table($atts, $content){		
		extract(shortcode_atts(array(
			'title' => '',
			'price'	=> '',
			'currency' => '$',
			'period' => __('per month','fastwp'),
			'is_first' => '0',
			'is_last' => '0',
			'is_active' => '0',
			'url'=>'javascript:void(0)',
			'button'=>__('Buy Now','fastwp'),
			'animation' => 'flipInY',
			'delay' => '0',
			'class'	=> '',
			'id'	=> '',
		), $atts));	
			$priceParts = explode(',', $price);
			$cents = '';
			if(count($priceParts) > 1){
				$cents = array_pop($priceParts);
			}
			$price = $currency . implode(',', $priceParts);	
			$price .= (isset($cents) && !empty($cents))?'<span>.'.$cents.'</span>':'';
			$id = (!empty($id))? sprintf('id="%s"', $id):'';
		return '			
			<div '.$id.' class="package animated'.(($is_first == '1')?' first':'').(($is_last == '1')?' last':'').(($is_active == '1')?' active':''). ' '.$class.'" data-animation="'.$animation.'" data-animation-delay="'.$delay.'">
				<h1>'.apply_filters('the_title', $title).'</h1>
				<div class="circle">
					<h2>'.$price.'</h2>
					<p>'.$period.'</p>
				</div>
				<ol>
					'.do_shortcode($content).'
				</ol>
				<a href="'.$url.'" class="p-btn">'.$button.'</a>
			</div>
		';
	}
	
	static function center($atts, $content){		
		extract(shortcode_atts(array(
			'valign' => '',
		), $atts));	
		$style = ($valign != '')?' style="vertical-align:'.$valign.';"':'';
		return '<div class="center-childs clearfix group">'.do_shortcode($content).'</div>';
	}
	
	static function group($atts, $content){		
		extract(shortcode_atts(array(
		), $atts));	
		return '<div class="group">'.do_shortcode($content).'<div class="clearfix group"></div></div>';
	}

	static function progress($atts, $content){		
		extract(shortcode_atts(array(
			'value' => '0',
			'suffix' => '%',
			'title' => '',
		), $atts));	
		$item_html = '<div class="progress-bars"><div class="progress-texts"><span class="progress-name">%s</span><span class="progress-value">%s%s</span><div class="clear"></div></div><div class="progress progress-striped active"><div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="%s" aria-valuemin="0" aria-valuemax="100" style="width: %s%%"></div></div></div>';

		return sprintf($item_html, $title, $value, $suffix, $value, $value);
	}
	
	static function about($atts, $content){		
		extract(shortcode_atts(array(
			'icon' 		=> '',
			'url' 		=> '',
			'title' 	=> '',
			'animation' => 'flipInY',
			'delay'		=> '0',
		), $atts));	
		
		$item_html = '<div class="about-content %s"%s>
					<div class="icon top">
						<i class="fa fa-%s"></i>
					</div>
					<div class="content-header text">%s</div>
					<div class="content-desc text">%s</div>
					<div class="icon bottom"><i class="fa fa-plus "></i></div></div>';
		$params = ($url != '')? sprintf(' onClick="document.location=\'%s\'; return false;"', $url):'';
		$params .= ($animation != '')? "data-animation='$animation' data-animation-delay='$delay'" : '';
		$class 	= ($animation != '')? ' animated ' : '';
		return sprintf($item_html, $class, $params, $icon, $title, do_shortcode($content));
	}
	
	static function facts($atts, $content){		
		extract(shortcode_atts(array(
			'value' 	=> '',
			'title' 	=> '',
			'delay' 	=> '200',
			'animation' => 'fadeIn',
			'icon'		=> '',
			'icon_size'	=> '3x',
		), $atts));	
		$icon_html = ($icon != '')? sprintf('<i class="fa fa-%s fa-%s"></i>', $icon, $icon_size) : '';
		$item_html = '<div class="col-xs-3 facts animated" data-animation="%s" data-animation-delay="%s" data-perc="%s">%s<h1 class="factor"></h1><p>%s</p></div>';
		return sprintf($item_html, $animation, $delay, $value, $icon_html, $title);
	}
		
	static function relative($atts, $content){	
		extract(shortcode_atts(array(
			'index' => '',
		), $atts));		
		$style = ($index != '')?' style="z-index:'.$index.'"':'';
		return sprintf('<div class="fastwp-relative" %s>%s</div>', $style, do_shortcode($content));
	}	
	
	static function absolute($atts, $content){		
		extract(shortcode_atts(array(
			'left' => '',
			'top' => '',
			'right' => '',
			'bottom' => '',
		), $atts));	
		
		$position =  ($left != '')	? 'left:'.	$left	.'px;':'';
		$position .= ($top != '')	? 'top:'.	$top	.'px;':'';
		$position .= ($right != '')	? 'right:'.	$right	.'px;':'';
		$position .= ($bottom != '')? 'bottom:'.$bottom	.'px;':'';
		return sprintf('<div class="fastwp-absolute" style="%s">%s</div>', $position, do_shortcode($content));
	}
	
	static function bg($atts, $content){		
		extract(shortcode_atts(array(
			'color' => '',
			'image' => '',
			'repeat' => 'no-repeat',
			'position' => 'top center',
			'padding' => '',
			'full' => ''
		), $atts));	
		$style = ($color != '')? 'background-color:'.$color.';' : '';
		$style .= ($image != '')? 'background-image: url('.$image.'); background-position: '.$position.'; background-repeat: '.$repeat.';' : '';
		$style .= ($padding != '')? 'padding:'.$padding.';' : '';
		$style .= (strtolower($full) == 'true')? 'width:100%; height:100%; position:absolute;' : '';
		return sprintf('<div class="fastwp-custom-bg" style="%s">%s</div>', $style, do_shortcode($content));
	}
	
	static function text_slider_with_bg($atts, $content){		
		extract(shortcode_atts(array(
			'image' => '',
			'height' => '',
		), $atts));	
		$style = ($image != '')?'background-image:url('.$image.')':'';
		$style .= ($height != '')?'min-height:'.$height:'';
		$_slides = explode('|', $content);
		if(!is_array($_slides) || count($_slides) == 0) return;
		
		$slide_tpl = '<div class="item %s"><div class="service-bottom-text">%s</div></div>';
		$wrap_tpl = '<div class=" text-carousel-with-bg " style="%s"><div id="carousel-%s" class="carousel slide slide-s" data-ride="carousel"><div class="carousel-inner service-text">%s</div><a class="left carousel-control s-controls" href="#carousel-%s" data-slide="prev"></a><a class="right carousel-control s-controls" href="#carousel-%s" data-slide="next"></a></div></div>';
		$slides = '';
		foreach($_slides as $slide){
			$class = ($slides == '')?'active':'';
			$slides .= sprintf($slide_tpl, $class, $slide);
		}
		$rand = rand(1000,9999);
		return sprintf($wrap_tpl, $style, $rand, $slides, $rand, $rand);
	}
	
	static function map($atts, $content){		
		extract(shortcode_atts(array(
			'height' => '',
		), $atts));	
		wp_enqueue_script('jquery');
		$style = ($height != '')? 'height:'.$height.';':'';
		return '<div id="google-map" style="'.$style.'">Loading...</div>';
	}
	
	static function accordion($atts, $content){		
		return sprintf('<div class="ui-accordion fastwp-accordion">%s</div>', do_shortcode($content));
	}
	
	static function accordion_item($atts, $content){		
		extract(shortcode_atts(array(
			'title' => '',
			'icon' => 'check',
		), $atts));	
		$item_html = '<div class="panel"><div class="accordion-heading"><i class="fa fa-%s"></i> %s</div><div class="accordion-inner">%s</div></div>';
		$item_html = '<div class="accordion-heading"><i class="fa fa-%s"></i> %s</div><div class="accordion-inner"><div>%s</div></div>';
		
		
		
		
		return sprintf($item_html, $icon, $title, do_shortcode($content));
	}
	
	/* Demo content shortcode */
	static function demo_revslider(){
		return '
				<!-- Rev Slider -->
		<section id="slider" class="contain">
		
		<div class="tp-banner">
		
		<ul>
			<!-- Slide -->
			<li class="revslide" data-transition="random" data-slotamount="7" data-masterspeed="800" >
					<!-- MAIN IMAGE -->
					<img src="'.get_template_directory_uri().'/demo/rev-slider/slide1.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
					<!-- LAYERS -->

					<!-- Layer 1 -->
					<div class="tp-caption  lft customout"
						data-x="700"
						data-y="110"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="500"
						data-start="1200"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on">
						<p class="stext p1">Clean And</p>
						<h1 class="stext h1">Responsive <span>Design</span></h1>
					</div>
					
					<!-- Layer 2 -->
					<div class="tp-caption  skewfromrightshort customout"
						data-x="700"
						data-y="180"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="500"
						data-start="1500"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on">
						<h2 class="stext h2">There are many variataons passages Lorem ıpsum<br/>The standard chunk of Lorem Ipsum</h2>
					</div>

					<!-- Layer 3 -->
					<div class="tp-caption customin customout"
						data-x="723" 
						data-y="280" 
						data-customin="x:0;y:50;z:0;rotationX:0;rotationY:0;rotationZ:0;skewX:0;skewY:0;opacity:0;transformPerspective:0;transformOrigin:50% 50%;"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="400"
						data-start="1700"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						>
						<img src="'.get_template_directory_uri().'/demo/rev-slider/s1.png" alt="">
					</div>
					
					<!-- Layer 4 -->
					<div class="tp-caption customin customout"
						data-x="723" 
						data-y="335" 
						data-customin="x:0;y:50;z:0;rotationX:0;rotationY:0;rotationZ:0;skewX:0;skewY:0;opacity:0;transformPerspective:0;transformOrigin:50% 50%;"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="400"
						data-start="1850"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						>
						<img src="'.get_template_directory_uri().'/demo/rev-slider/s2.png" alt="">
					</div>
					
					<!-- Layer 5 -->
					<div class="tp-caption customin customout"
						data-x="723" 
						data-y="390" 
						data-customin="x:0;y:50;z:0;rotationX:0;rotationY:0;rotationZ:0;skewX:0;skewY:0;opacity:0;transformPerspective:0;transformOrigin:50% 50%;"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="400"
						data-start="2000"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						>
						<img src="'.get_template_directory_uri().'/demo/rev-slider/s3.png" alt="">
					</div>
					
					<!-- Layer 6 -->
					<div class="tp-caption customin customout"
						data-x="780" 
						data-y="280" 
						data-customin="x:50;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;skewX:0;skewY:0;opacity:0;transformPerspective:0;transformOrigin:50% 50%;"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="400"
						data-start="1700"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						>
						<h3 class="stext h3">There are many variations of passages.</h3>
					</div>
					
					<!-- Layer 7 -->
					<div class="tp-caption customin customout"
						data-x="780" 
						data-y="335" 
						data-customin="x:50;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;skewX:0;skewY:0;opacity:0;transformPerspective:0;transformOrigin:50% 50%;"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="400"
						data-start="1850"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						>
						<h3 class="stext h3">Contrary to popular.</h3>
					</div>
					
					<!-- Layer 8 -->
					<div class="tp-caption customin customout"
						data-x="780" 
						data-y="390" 
						data-customin="x:50;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;skewX:0;skewY:0;opacity:0;transformPerspective:0;transformOrigin:50% 50%;"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="400"
						data-start="2000"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						>
						<h3 class="stext h3">popular belief, Lorem Ipsum.</h3>
					</div>
					
					
			</li>
			
			
			<!-- Slide -->
			<li class="revslide" data-transition="random" data-slotamount="7" data-masterspeed="800" >
					<!-- MAIN IMAGE -->
					<img src="'.get_template_directory_uri().'/demo/rev-slider/slide2.jpg"  alt="slidebg2"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
					<!-- LAYERS -->

					<!-- Layer 1 -->
					<div class="tp-caption sft customout"
						data-x="0"
						data-y="220"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="900"
						data-start="1400"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on">
						<h4 class="stext h4 fittext4">clean and responsive design</h4>
					</div>
					
					<!-- Layer 2 -->
					<div class="tp-caption sfb customout"
						data-x="10"
						data-y="320"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="900"
						data-start="1700"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on">
						<h5 class="stext h5">There are many variataons of passages Lorem ıpsum The standard chunk</h5>
					</div>
					
			</li>
			
			<!-- Slide -->
			<li class="revslide" data-transition="random" data-slotamount="7" data-masterspeed="800" >
					<!-- MAIN IMAGE -->
					<img src="'.get_template_directory_uri().'/demo/rev-slider/slide3.jpg"  alt="slidebg3"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
					<!-- LAYERS -->

					<!-- Layer 1 -->
					<div class="tp-caption sfl customout"
						data-x="0"
						data-y="185"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="900"
						data-start="1200"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on">
						<h6 class="stext h6">it’s <span>wisten</span> time</h6>
					</div>
					
					<!-- Layer 2 -->
					<div class="tp-caption sfl customout"
						data-x="0"
						data-y="245"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="900"
						data-start="1500"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on">
						<p class="stext p5">super responsive, clean creative theme</p>
					</div>
					
					<!-- Layer 3 -->
					<div class="tp-caption sfb customout"
						data-x="0"
						data-y="275"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="900"
						data-start="1800"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on">
						<p class="stext p6">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praes<br/>entium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi<br/>sint occaecati</p>
					</div>
					
					<!-- Layer 4 -->
					<div class="tp-caption sfb customout not-mobile"
						data-x="0"
						data-y="345"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="900"
						data-start="2100"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on">
						<img src="'.get_template_directory_uri().'/demo/rev-slider/check.png" alt="check"/>
					</div>
					
					<!-- Layer 5 -->
					<div class="tp-caption sfb customout not-mobile"
						data-x="20"
						data-y="345"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="900"
						data-start="2150"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on">
						<p class="stext p6">Parallax Efect</p>
					</div>
					
					<!-- Layer 6 -->
					<div class="tp-caption sfb customout not-mobile"
						data-x="118"
						data-y="345"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="900"
						data-start="2200"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on">
						<img src="'.get_template_directory_uri().'/demo/rev-slider/check.png" alt="check"/>
					</div>
					
					<!-- Layer 7 -->
					<div class="tp-caption sfb customout not-mobile"
						data-x="138"
						data-y="345"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="900"
						data-start="2250"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on">
						<p class="stext p6">Professional Look</p>
					</div>
					
					<!-- Layer 8 -->
					<div class="tp-caption sfb customout not-mobile"
						data-x="260"
						data-y="345"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="900"
						data-start="2300"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on">
						<img src="'.get_template_directory_uri().'/demo/rev-slider/check.png" alt="check"/>
					</div>
					
					<!-- Layer 9 -->
					<div class="tp-caption sfb customout not-mobile"
						data-x="280"
						data-y="345"
						data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-speed="900"
						data-start="2350"
						data-easing="Power4.easeOut"
						data-endspeed="500"
						data-endeasing="Power4.easeIn"
						data-captionhidden="on">
						<p class="stext p6">One Page Design</p>
					</div>
					
			</li>
			
			 </ul>
		</div>
		</section>
		<!-- End Rev Slider -->
		';
	
	}

	static function has_shortcode( $shortcode ) {
		global $shortcode_tags;
	
		return ( in_array( $shortcode, array_keys ( $shortcode_tags ) ) ? true : false);
	}

	static function add_shortcode( $shortcode, $shortcode_function ) {
	
	if( !self::has_shortcode( $shortcode ) )
		add_shortcode( $shortcode, array( __CLASS__, $shortcode_function ) );
	}

	static function init() {

		self::add_shortcode( 'tab', 'tab_shortcode' );
		self::add_shortcode( 'tabs', 'tabs_shortcode' );
		

		add_action( 'init', array(__CLASS__, 'register_script_and_style' ) );
		add_action( 'wp_footer', array(__CLASS__, 'print_script' ) );
		
		add_action( 'wp_enqueue_scripts', array(__CLASS__, 'enqueue_style' ) );
		
		/* Apply filters to the tabs content. */
		add_filter( 'tab_content', 'wpautop' );
		add_filter( 'tab_content', 'shortcode_unautop' );
		add_filter( 'tab_content', 'do_shortcode' );
		
		self::$shortcode_count = 0;
		self::$current_active_content = 0;
		

	}
	
	static function init_tabs(){
		add_filter( 'tab_content', 'wpautop' );
		add_filter( 'tab_content', 'shortcode_unautop' );
		add_filter( 'tab_content', 'do_shortcode' );
		self::$shortcode_count = 0;
		self::$current_active_content = 0;
	}
	
	public static  function tab_shortcode( $atts, $content ) {
		global $post;
		
		extract(shortcode_atts(array(
					'title' => null,
					'class' => null,
				), $atts) );

		$selected = ( self::$current_active_content == self::$shortcode_count ? true : false );

		$class = apply_filters( "tabs-shortcode-content-panel-class", $class, $selected );
		$class .= ($selected == true)?' in active ':'';
		$class .= ' tab-pane fade clearfix group';
		$class_atr  = ( empty( $class ) ? '' : 'class=" '.$class.' "' );
		$title 		= ( empty( $title ) ? $post->post_title : $title );
		$id 		= preg_replace("/[^A-Za-z0-9]/", "", $title )."-".self::$shortcode_count;
		
		
		if( empty( $title ) )
			return '<span style="color:red">Please enter a title attribute like [tab title="title name"]tab content[tab]</span>';
		
		self::$shortcode_data[  self::$current_tab_id ][] = array( 'title' => $title, 'id' => $id , 'class' => $class );
		
		self::$shortcode_count++;

		return '<div id="'.$id.'" '.$class_atr.' >'. apply_filters( 'tab_content', $content ). '</div>';
		
	}

	static $add_script;
	static $shortcode_count;
	static $current_active_content;
	static $shortcode_data;
	static $shortcode_js_data;
	static $current_tab_id;
	static $tabs_support;
	
	public static function tabs_shortcode( $atts, $content ) {
		
		self::$add_script =  true;

		if( is_string($atts) )
			$atts = array();
		
		if( isset( $atts['vertical_tabs'] ) ):
			$vertical_tabs = ( self::eval_bool( $atts['vertical_tabs'] ) ? "vertical-tabs": "");
			unset($atts['vertical_tabs']);
		else:
			$vertical_tabs = "";
		endif;
		
		if( isset( $atts['position'] )  && in_array( $atts['position'], array( 'top', 'bottom', 'left', 'right' ) ) ):
			$position = $atts['position'];
		else:
			$position = ( empty($vertical_tabs) ? 'top' : 'left');
		endif;
		
		// optional attributes
		
		$attr['collapsible'] =  ( isset($atts['collapsible']) ? self::eval_bool( $atts['collapsible'] ) : false );
		$attr['selected']  	=   ( isset($atts['selected']) ? (int)$atts['selected'] : 0);
		$attr['event']  	=   ( isset($atts['event']) && in_array($atts['event'], array('click', 'mouseover') ) ? $atts['event'] : 'click');
		
		self::$current_active_content = $attr['selected'] + self::$shortcode_count;
		
		$query_atts = shortcode_atts( array(
				'collapsible'	=> false,
				'selected' 		=> 0,
				'event'   		=> 'click',
			), $attr );
		
		// self::$current_tab_id = "random-tab-id-".rand(0,1000);
		self::$current_tab_id = "tab-menu";
		
		$content = str_replace( "]<br />","]", ( substr( $content, 0 , 6 ) == "<br />" ? substr( $content, 6 ): $content ) );
		
		self::$shortcode_js_data[ self::$current_tab_id ] = $query_atts;
		
		$individual_tabs = do_shortcode( $content );
		$individual_tabs = apply_filters( 'tabs-shortcode-content-shell', $individual_tabs );
		
		$shell_class = apply_filters( 'tabs-shortcode-shell-class', "tabs-shortcode ". $vertical_tabs." tabs tabs-shortcode-".$position, $position );
		$list_class  = apply_filters( 'tabs-shortcode-list-class', "tabs-shortcode-list" );
		
		$list_attr   = apply_filters( 'tabs-shortcode-list-attr', ''); // don't 
		$list_link_attr   = apply_filters( 'tabs-shortcode-list-link-attr', ''); // don't 
		ob_start();
		
		?><div id="<?php echo self::$current_tab_id ?>" class="<?php echo $shell_class ?>"><?php
		
			if( $position == 'bottom' )
				echo '<div class="tab-content">'.$individual_tabs.'</div>';
?>
			<ul class="<?php echo $list_class ?> nav nav-tabs" id="tab-menu<?php echo rand(10,99); ?>">
			<?php
			/* <li data-toggle="tab" <?php if( $tab_data['class']): ?> class="<?php echo $tab_data['class'];?>  " <?php echo $list_attr; ?> <?php endif; ?> ><a href="#<?php echo $tab_data['id']; ?>" <?php echo $list_link_attr; ?>><?php echo $tab_data['title']; ?></a></li><?php 
			*/	
			$list_counter_class = 0;
			foreach( self::$shortcode_data[self::$current_tab_id] as $tab_data ): ?>
				<li <?php if( $tab_data['class'] && substr_count($tab_data['class'], 'active')): ?> class="active" <?php echo $list_attr; ?> <?php endif; ?> ><a data-toggle="tab" href="#<?php echo $tab_data['id']; ?>" <?php echo $list_link_attr; ?>><?php echo $tab_data['title']; ?></a></li><?php 
			$list_counter_class++;
			endforeach;
			
			?></ul><?php 
			
			
			if( $position != 'bottom' )
				echo '<div class="tab-content">'.$individual_tabs.'</div>';
			
			?></div><?php
					
		return apply_filters( 'tab_content', str_replace("\r\n", '',  ob_get_clean() ) );

	}
	
	static function eval_bool( $item ) {
		
		return ( (string) $item == 'false' || (string)$item == 'null'  || (string)$item == '0' || empty($item)   ? false : true );
	}

	static function grid_column($atts, $content){		
		extract(shortcode_atts(array(
			'size' 	=> '12',
			'type' 	=> 'xs',
			'hide' 	=> '',
			'class' => '',
			'id' 	=> '',
		), $atts));	
		$extra_class 	= ($size > 4)?' full-below-800 ':'';
		$extra_class 	.= ($hide == 'true')?' hide-below-800 ':'';
		$extra_class 	.= $class;
		$id 			= ($id != '')? sprintf(' id="%s"', $id) : '';
		return sprintf('<div class="col-%s-%s %s"%s>%s</div>', $type, $size, $extra_class, $id,  do_shortcode($content));
	}
	
	static function font_awesome($atts, $content){		
		extract(shortcode_atts(array(
			'icon' => '',
			'size' => '',
		), $atts));	
		$icon = ($icon == '')? $content : $icon;
		$size = ($size != '')? 'fa-'.$size : '';
		return sprintf('<i class="fa fa-%s %s"></i>', $icon, $size);
	}
		
	static function super_slides_slide($atts, $content){		
		extract(shortcode_atts(array(
			 'pattern' 	=> 'true',
			 'parallax' => 'true',
			 'bg'=>'',
		), $atts));	
		
		$class = ($pattern == 'true')? ' pattern ':'';
		$class .= ($parallax == 'true')? ' fastwp-parallax ':'';
		$custom = ($parallax == 'true')? ' data-speed="50" ':'';
		$style = ($bg != '')? ' background-image:url('.$bg.') ':'';
		
		$item_template = '<div class="%s" style="%s" %s>%s</div>';
		return sprintf($item_template, $class, $style, $custom, do_shortcode($content));
	}
	
	static function super_slides($atts, $content){		
		extract(shortcode_atts(array(
			'pattern' 	=> 'true',
			'random'	=> 'false',
		), $atts));	
		if($random == 'true'){
			if(substr_count($content, '[sslide ') > 1){
				$slides = explode('[sslide ', $content);
				for($i=0; $i<count($slides); $i++){
					$slides[$i] = '[sslide '.$slides[$i];
				}
				shuffle($slides);
				$content = implode('', $slides);
				unset($slides);
			}
		}
		$wrapper_template = '<div class="fastwp-superslides"><div class="slides-container">%s</div><nav class="slides-navigation"><a href="#" class="next"></a><a href="#" class="prev"></a></nav></div>';
		return sprintf($wrapper_template, do_shortcode($content));
	}
	
	static function pattern_bg($atts, $content){		
		extract(shortcode_atts(array(
			 'style' 	=> 'pattern',
			 'bg' 		=> '',
		), $atts));	
		$background = ($bg != '')			? 'style="background-image:url('.$bg.')"':'';
		$extra 		= ($style=='pattern')	? '<div class="home-pattern-style" '.$background.'></div>':'';
		return sprintf('<div class="%s fastwp-superslides">%s %s</div>', $style, $extra, do_shortcode($content));
	}
			
	static function flex_slider($atts, $content){		
		extract(shortcode_atts(array(
			'style' => 'home-slider',
		), $atts));	
		return sprintf('<div class="flexslider %s"><ul class="home-slides">%s</ul></div>', $style, do_shortcode($content));
	}

	static function flex_slider_slide($atts, $content){		
		return sprintf('<li>%s</li>', do_shortcode($content));
	}
	
	static function main($atts, $content){		
		extract(shortcode_atts(array(
			'index' 	=> '',
			'position' 	=> 'relative',
		), $atts));
		$style = ($index != '')? sprintf(' style="position:%s; z-index:%s;"', $position, $index) : '';
		return sprintf('<div class="main"%s>%s</div>', $style, do_shortcode($content));
	}
	
	static function button($atts, $content){		
		extract(shortcode_atts(array(
			'href' 		=> '',
			'target' 	=> '',
		), $atts));	
			$target 	= ($target == 'new')		? '_blank':$target;
			$class 		= (substr($href,0,1) == '#')? 'scroll':'';
			$target 	= ($target != '')			? ' target="'.$target.'" ':'';
			$target 	.= ($class=='scroll')? ' data-hash="'.$href.'"':'';
		return sprintf('<a class="%s home-button" href="%s" %s>%s</a>', $class, $href, $target, $content);
	}
}

add_shortcode('button', 		array('fastwp_shortcodes_fe','button'));
add_shortcode('pattern-bg', 	array('fastwp_shortcodes_fe','pattern_bg'));
add_shortcode('main', 			array('fastwp_shortcodes_fe','main'));
add_shortcode('slide', 			array('fastwp_shortcodes_fe','flex_slider_slide'));
add_shortcode('f-slider', 		array('fastwp_shortcodes_fe','flex_slider'));
add_shortcode('sslide', 		array('fastwp_shortcodes_fe','super_slides_slide'));
add_shortcode('super-slides', 	array('fastwp_shortcodes_fe','super_slides'));
add_shortcode('text-slider', 	array('fastwp_shortcodes_fe','text_slider_with_bg'));
add_shortcode('add-border', 	array('fastwp_shortcodes_fe','with_border'));
add_shortcode('phone', 			array('fastwp_shortcodes_fe','fastwp_phone'));
add_shortcode('fa', 			array('fastwp_shortcodes_fe','font_awesome'));
add_shortcode('grid', 			array('fastwp_shortcodes_fe','grid_column'));
add_shortcode('column', 		array('fastwp_shortcodes_fe','grid_column'));
add_shortcode('accordion', 		array('fastwp_shortcodes_fe','accordion'));
add_shortcode('item', 			array('fastwp_shortcodes_fe','accordion_item'));
add_shortcode('fastwp-page', 	array('fastwp_shortcodes_fe','fastwp_get_page'));
add_shortcode('page', 			array('fastwp_shortcodes_fe','fastwp_get_page'));
add_shortcode('product-info', 	array('fastwp_shortcodes_fe','productInfo'));
add_shortcode('testimonials', 	array('fastwp_shortcodes_fe','testimonials'));
add_shortcode('members', 		array('fastwp_shortcodes_fe','members'));
add_shortcode('services', 		array('fastwp_shortcodes_fe','services'));
add_shortcode('box', 			array('fastwp_shortcodes_fe','box'));
add_shortcode('head', 			array('fastwp_shortcodes_fe','header'));
add_shortcode('header', 		array('fastwp_shortcodes_fe','header'));
add_shortcode('desc', 			array('fastwp_shortcodes_fe','desc'));
add_shortcode('description', 	array('fastwp_shortcodes_fe','desc'));
add_shortcode('center', 		array('fastwp_shortcodes_fe','center'));
add_shortcode('group', 			array('fastwp_shortcodes_fe','group'));
add_shortcode('pricing_table', 	array('fastwp_shortcodes_fe','pricing_table'));
add_shortcode('pricing-table', 	array('fastwp_shortcodes_fe','pricing_table'));
add_shortcode('progress', 		array('fastwp_shortcodes_fe','progress'));
add_shortcode('tab', 			array('fastwp_shortcodes_fe','tab_shortcode'));
add_shortcode('tabs', 			array('fastwp_shortcodes_fe','tabs_shortcode'));
add_shortcode('about-item', 	array('fastwp_shortcodes_fe','about'));
add_shortcode('facts', 			array('fastwp_shortcodes_fe','facts'));
add_shortcode('bg', 			array('fastwp_shortcodes_fe','bg'));
add_shortcode('absolute', 		array('fastwp_shortcodes_fe','absolute'));
add_shortcode('relative', 		array('fastwp_shortcodes_fe','relative'));
add_shortcode('map', 			array('fastwp_shortcodes_fe','map'));
add_shortcode('newsletter', 	array('fastwp_shortcodes_fe','newsletter_form'));
add_shortcode('mailchimp', 		array('fastwp_shortcodes_fe','newsletter_form'));
add_shortcode('full_background',array('fastwp_shortcodes_fe','full_background'));
add_shortcode('parallax', 		array('fastwp_shortcodes_fe','parallax'));
add_shortcode('twitter-feed', 	array('fastwp_shortcodes_fe','twitter_feed'));
add_shortcode('twitter', 		array('fastwp_shortcodes_fe','twitter_feed'));
add_shortcode('divider', 		array('fastwp_shortcodes_fe','divider')); 
add_shortcode('space', 			array('fastwp_shortcodes_fe','space')); 
add_shortcode('call-to-action', array('fastwp_shortcodes_fe','call_to_action')); 
add_shortcode('chart', 			array('fastwp_shortcodes_fe','pie_chart')); 
add_shortcode('pie-chart', 		array('fastwp_shortcodes_fe','pie_chart')); 
add_shortcode('fastwp-chart', 	array('fastwp_shortcodes_fe','pie_chart')); 
add_shortcode('revslider-demo', array('fastwp_shortcodes_fe','demo_revslider'));

fastwp_shortcodes_fe::init_tabs();