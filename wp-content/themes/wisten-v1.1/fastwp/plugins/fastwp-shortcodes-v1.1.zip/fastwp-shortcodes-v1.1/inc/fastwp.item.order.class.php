<?php

add_action('admin_ajax_save_order', 'fastwp_save_order');
add_action('wp_ajax_save_order', 'fastwp_save_order');
function fastwp_save_order(){
	$nonce = $_POST['security'];
	if ( ! wp_verify_nonce( $nonce, 'fastwp-nonce' )  && true == false)
		die ( 'No, no, no !!!!');
		wp_parse_str(stripslashes($_POST['data']), $data);
		unset($data['security']);
		echo fastwp_admin_order::update_order($data['posts']);
	exit;
}
			                    

function fastwp_add_order_edit(){
	$types = array(
		'fwp_service' => 'Services',
		'fwp_team' => 'Member',
		'fwp_portfolio' => 'Portfolio',
	);
	foreach($types as $k=>$v){
		add_submenu_page( 'edit.php?post_type='.$k, $v.' order', 'Reorder', 'manage_options', $k.'-reorder-menu', array('fastwp_admin_order','reorder_items') );
	}
}
add_action( 'admin_menu', 'fastwp_add_order_edit' );


class fastwp_admin_order {
	public static function reorder_items(){
		$type = (isset($_GET['post_type']))?$_GET['post_type']:'';
		if($type == '') { return; }
		
		$posts = get_posts('post_type='.$type.'&orderby=menu_order&order=ASC&numberposts=-1&post_status=publish');
		
		
		// var_dump($posts);
		echo '<h1>'.__('Change items order','fastwp').'</h1>';
		echo '<div class="message updated" style="display:none;">loading...</div>
		<form action="" id="post-reorder-'.$type.'" class="fastwp-order-post-form"><ul class="order sortable"><input type="hidden" name="action" class="action" value="save_order">';
		foreach($posts as $post){
			echo '<li class="grid-item">
			
			<input type="hidden" name="posts[]" value="'.$post->ID.'"><div class="thumb">'.get_the_post_thumbnail( $post->ID, array(64,64)).'</div>
			<b>'.$post->post_title.'</b>
			</li>';
		}
		echo '</ul>
		<a class="button save-settings">Save order</a>
		
		</form>';
		
		//var_dump($posts);
	}
	
	public static function update_order($DATA){
		global $wpdb;
		$position= 1;
		foreach($DATA as $id){
			$wpdb->update( $wpdb->posts, array('menu_order' => $position), array('ID' => $id) );
			$position++;
		}
		$message = array(
			'status'=>'1',
			'message'=> '<p>'.__('Order updated','clapat').'</p>',
		);
		echo json_encode($message);
		exit;
	}
	
}