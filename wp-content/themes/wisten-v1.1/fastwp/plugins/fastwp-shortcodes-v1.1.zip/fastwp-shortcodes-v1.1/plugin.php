<?php
/**
 * @package FastWP_Shortcodes
 * @version 1.1
 */
/*
Plugin Name: FastWP Shortcodes
Plugin URI: http://fastwp.net/plugins/#shortcodes
Description: This plugin is required in order to run themes version 1.1 built by fastwp
Author: FastWP
Version: 1.1
Author URI: http://fastwp.net
*/

define('FASTWP_SHORTCODE', true);
define('FASTWP_SHORTCODE_VERSION', '1.1');
define('FASTWP_SHORTCODE_PATH', dirname(__FILE__));

require FASTWP_SHORTCODE_PATH . '/inc/fastwp.item.order.class.php';
require FASTWP_SHORTCODE_PATH . '/inc/fastwp.shortcode.class.php';
if(!function_exists('print_admin_notices')):
	function print_admin_notices() {

	}
	add_action( 'admin_notices', 'print_admin_notices' );
endif;

if(!function_exists('add_plugin_css')):
	function add_plugin_css() {

	}
	add_action( 'admin_head', 'add_plugin_css' );
endif;

if(!function_exists('add_plugin_admin_css_js')):
function add_plugin_admin_css_js(){
	if(is_admin()){
			wp_enqueue_script('jquery-ui-core');
			wp_enqueue_script('jquery-ui-sortable');
			
		wp_enqueue_style('fwp-plugin-style' , plugin_dir_url(__FILE__).'assets/css/admin.css');
		wp_enqueue_script( 'fwp-plugin-script',  plugin_dir_url(__FILE__).'assets/js/admin.js', 'jquery', '1.0.0', true); 
	}
}
add_action( 'admin_enqueue_scripts', 'add_plugin_admin_css_js' );
endif;

if(!function_exists('fastwp_add_styles_and_scripts')):
	function fastwp_add_styles_and_scripts(){
		/* Ignore if admin or login page*/
		if(!is_admin() && !is_login_page()){
			global $smof_data;
			$new_lines = array("\r\n","\r","\n");
			/* Build map data */
			$data = array(
				'plugin_dir' => plugin_dir_url(__FILE__).'assets/',
				'center' => array(
					'lat'=>(isset($smof_data['map_lat']))	?$smof_data['map_lat']: '44',
					'lng'=>(isset($smof_data['map_lng']))	?$smof_data['map_lng']: '26',
				),
				'zoom' => (isset($smof_data['map_zoom']))? $smof_data['map_zoom'] : '16',
				'style' => array(
					'enabled' 	=> (isset($smof_data['map_custom']))			?$smof_data['map_custom']			: '0', 		 // map_custom
					'road' 		=> (isset($smof_data['map_color_road']))		?$smof_data['map_color_road']		: '#000000', // map_color_road
					'landscape' => (isset($smof_data['map_color_landscape']))	?$smof_data['map_color_landscape']	: '#141414', // map_color_landscape
					'label' 	=> (isset($smof_data['map_color_labels']))		?$smof_data['map_color_labels']		: '#7f8080', // map_color_labels
					'label_fill'=> (isset($smof_data['map_color_labels_fill']))	?$smof_data['map_color_labels_fill']: '#808080', // map_color_labels_fill
					'poi'	 	=> (isset($smof_data['map_color_poi']))			?$smof_data['map_color_poi']		: '#161616', // map_color_poi
				),
			);
			/* Build marker data */
			for($i=1;$i<=3;$i++){
				$data['marker']['m_'.$i] = array(
					'enable'=> (isset($smof_data['map_marker_1']))?$smof_data['map_marker_'.$i]: '0',
					'title'=> (isset($smof_data['map_ttl_m'.$i]))	?$smof_data['map_ttl_m'.$i]: '',
					'lat'=> (isset($smof_data['map_lat_m'.$i]))	?$smof_data['map_lat_m'.$i]: '0',
					'lng'=> (isset($smof_data['map_lng_m'.$i]))	?$smof_data['map_lng_m'.$i]: '0',
					'ct'=> (isset($smof_data['map_ct_m'.$i]))	? str_replace($new_lines, '', nl2br($smof_data['map_ct_m'.$i])): '',
				);
			}

			wp_enqueue_script('jquery');
			wp_enqueue_script('jquery-ui-accordion');
			wp_enqueue_script( 'google-maps', 'http://maps.google.com/maps/api/js?sensor=false', 'jquery', '1.0', true );
			wp_localize_script( 'jquery', 'fastwp_map_settings', $data );
			$scripts = array(
				'jquery.flexslider',
				'jquery.easypiechart.min',
				'jquery.doScroll',
				'shortcodes',
			);
	
			foreach($scripts as $script){
				wp_enqueue_script( $script, plugin_dir_url(__FILE__).'assets/js/'.$script.'.js', 'jquery', '1.0', true );
			}
			
			/* Load our stylesheets.*/
			$styles = array(
			'flexslider',
			'shortcodes',
			);
			foreach($styles as $style){
				wp_enqueue_style( $style, plugin_dir_url(__FILE__).'assets/css/'.$style.'.css');
			}
		}
	}
	add_action('wp_enqueue_scripts', 'fastwp_add_styles_and_scripts');
endif;

if(!function_exists('is_login_page')):
	function is_login_page() {
		return in_array($GLOBALS['pagenow'], array('wp-login.php', 'wp-register.php'));
	}
endif;

add_filter('deprecated_function_trigger_error', '_no_deprecated_func_alert');
function _no_deprecated_func_alert($x){
	return false;
}


add_filter("the_content", "the_content_filter");
function the_content_filter($content) {
 
	// array of custom shortcodes requiring the fix 
	$block = join("|",array("column", "portfolio", "team-member", "timeline", "video-bg", "button", "pattern-bg", "f-slider", "slide", "super-slides", "sslide", "text-slider", "add-border", "phone", "fa", "grid", "accordion", "item", "fastwp-page", "product-info", "testimonials", "members", "services", "box", "header", "desc", "center", "group", "pricing-table","pricing_table", "progress", "tabs", "tab", "about-item", "facts", "bg", "absolute", "relative", "space", "divider", "map", "mailchimp", "twitter-feed", "call-to-action", "pie-chart", "revslider-demo"));
 
	// opening tag
	$rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
		
	// closing tag
	$rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
 
	return $rep;
 
}