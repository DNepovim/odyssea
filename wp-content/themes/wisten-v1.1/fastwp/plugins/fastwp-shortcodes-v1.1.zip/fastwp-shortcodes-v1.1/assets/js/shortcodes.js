/**	This package is part of FastWP framework.*	Is available with all themes for compatibility*/
var fastwp_shortcodes_loaded = true;
var fastwp_debug = false;
if (typeof fastwp_debug == 'undefined') {
    fastwp_debug = false;
}
if (typeof fastwp_owl_loaded == 'undefined') {
    var fastwp_owl_loaded = false;
}
jQuery(function ($) {
    if (fastwp_owl_loaded == false && typeof $('body').owlCarousel == 'function') {
        if (fastwp_debug == true) {
            console.warn('OWL Sliders loaded from plugin.');
        }
		$(".slide-boxes").each(function(){
			var cfg = $(this).data('config');
			if(typeof cfg != 'undefined'){
			cfg = eval('('+cfg+')');
			console.log(cfg);
				$(this).owlCarousel(cfg);
			}else {
				$(this).owlCarousel();
			}
		});
        fastwp_owl_loaded = true;
    }
});

jQuery(function ($) {
    $(window).on('smartresize', function(){
		setFullHeight();
	});
	setFullHeight();
	
	var elements = $('.with-scroll-bg');
	if(elements.length > 0){
		elements.each(function(){
			var scroll_speed 		= jQuery(this).data('speed');
			var scroll_direction 	= jQuery(this).data('direction');
			jQuery(this).bgscroll({scrollSpeed:scroll_speed , direction:scroll_direction });
		});
	}
	
});
jQuery(function ($) {
    $('.pie-chart').easyPieChart({
        easing: 'easeInOutQuart',
        scaleLength: 0,
        lineWidth: 5,
        barColor: '#f0f0f0',
        trackColor: '#fcfcfc',
        onStep: function (from, to, percent) {
            $(this.el).find('.percent').text(Math.round(percent));
        }
    });
});
jQuery(function ($) {
    if (typeof mc4wp != 'undefined') {
        if (mc4wp.success == '1') {
            alert("Your email (" + mc4wp.postData.EMAIL + ") has ben added to database.\nThank you for subscribe.");
        } else {
            alert("Your email (" + mc4wp.postData.EMAIL + ") has not been added to database.\nDid you already added?.");
        }
    }
});
jQuery(function ($) {
    if (typeof $('.testimonial').flexslider == 'function') {
        var flex_settings = {
            animation: "fade",
            selector: ".testimonials .monial",
            controlNav: false,
            directionNav: true,
            slideshowSpeed: 7000,
            direction: "horizontal",
            start: function (slider) {
                $('body').removeClass('loading');
            }
        }
        $('.testimonial').flexslider(flex_settings);
        flex_settings.selector = '.text-slider > li';
        $('.twitter-feed').flexslider(flex_settings);
    }
    if (typeof $('body').parallax == 'function') {
        $('.fastwp-parallax').parallax();
    }
    if (typeof $('body').accordion == 'function') {
        $('.fastwp-accordion').accordion({
            heightStyle: "content"
        })
    }
    if (typeof $('body').appear == 'function') {
        $('.animated').appear();
        $('.animated').on('appear', function () {
            var elem = $(this);
            var animation = elem.data('animation');
            if (!elem.hasClass('visible')) {
                var animationDelay = elem.data('animation-delay');
                if (animationDelay) {
                    setTimeout(function () {
                        elem.addClass(animation + " visible");
                    }, animationDelay);
                } else {
                    elem.addClass(animation + " visible");
                }
            }
        });
    }
});
var markers = [];
var info_window = [];
jQuery(function ($) {
    'use strict';
    if (typeof google == 'undefined') {
        console.warn('Google class does not exist.');
        return;
    }
    if (typeof fastwp_map_settings == 'undefined') {
        console.warn('fastwp_map_settings does not exist.');
        return;
    }
    if (typeof $('#google-map').html() != 'string') {
        console.warn('Google map container not found. Skip initialization.');
        return;
    }
    var latlng = new google.maps.LatLng(fastwp_map_settings.center.lat, fastwp_map_settings.center.lng);
    var color_road = "#000000";
    var color_landscape = "#141414";
    var color_text = "#7f8080";
    var color_textfill = "#808080";
    var color_poi = "#161616";
    var map_options = {
        zoom: parseInt(fastwp_map_settings.zoom),
        center: latlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        disableDefaultUI: true,
        scrollwheel: false,
    };
    if (fastwp_map_settings.style.enabled == '1') {
        var color_road = fastwp_map_settings.style.road;
        var color_landscape = fastwp_map_settings.style.landscape;
        var color_text = fastwp_map_settings.style.label;
        var color_textfill = fastwp_map_settings.style.label_fill;
        var color_poi = fastwp_map_settings.style.poi;
        var styles = [{
            "featureType": "road",
            "stylers": [{
                "color": color_road
            }]
        }, {
            "featureType": "landscape",
            "stylers": [{
                "color": color_landscape
            }]
        }, {
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": color_textfill
            }]
        }, {
            "featureType": "poi",
            "stylers": [{
                "color": color_poi
            }]
        }, {
            "elementType": "labels.text",
            "stylers": [{
                "saturation": 1
            }, {
                "weight": 0.1
            }, {
                "color": color_text
            }]
        }];
        map_options.styles = styles;
    }
    var map = new google.maps.Map(document.getElementById('google-map'), map_options);
    var i = 0;
    for (var j = 1; j <= 3; j++) {
        if (fastwp_map_settings['marker']['m_' + j]['enable'] == '1') {
            var marker_content = fastwp_map_settings['marker']['m_' + j]['ct'];
            var marker_lat = fastwp_map_settings['marker']['m_' + j]['lat'];
            var marker_lng = fastwp_map_settings['marker']['m_' + j]['lng'];
            var marker_title = 'FastWp';
            var content_string = '<div id="content">' + marker_content + '</div>';
            info_window[i] = new google.maps.InfoWindow({
                content: content_string
            });
            var marker_coord = new google.maps.LatLng(marker_lat, marker_lng);
            var image = fastwp_map_settings.plugin_dir + 'images/marker.png';
            markers[i] = new google.maps.Marker({
                position: marker_coord,
                map: map,
                title: marker_title,
                icon: image
            });
            i++;
        }
    }
    for (var i = 0; i < markers.length; i++) {
        if (fastwp_debug == true) { console.log(info_window[i]); } 
		google.maps.event.addListener(markers[i], 'click', makeMapListener(info_window[i], map, markers[i], info_window));
    }
});

function makeMapListener(window, map, markers, all) {
    return function () {
        for (var i = 0; i < all.length; i++) {
            all[i].close();
        }
        window.open(map, markers);
    };
}

function setFullHeight(){
	var w_height = jQuery(window).height();
	jQuery('.fastwp-full-bg').outerHeight(w_height);
}